//
//  ViewController.swift
//  BootCampProjectOne
//
//  Created by Arpit 24 on 01/07/26.
//

import UIKit

class LogInViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        if let createAccVC = storyBoard.instantiateViewController(withIdentifier: "SelectionViewController") as? SelectionViewController {
            navigationController?.pushViewController(createAccVC, animated: true)
        }
        // Do any additional setup after loading the view.
    }


}

